#pragma once
#include <cstring>
#include "DetalleVenta.h"

class DetalleVentaArchivo {
private:
    char _nombreArchivo[30];
    int tamanioRegistro;

public:
    DetalleVentaArchivo(const char *nombreArchivo = "detallesVentas.dat") {
        strcpy(_nombreArchivo, nombreArchivo);
        tamanioRegistro = sizeof(DetalleVenta);
    }

    float altaDetalle(int idVenta);
    int agregarRegistro(DetalleVenta reg);
    DetalleVenta leerRegistro(int pos);
    int buscarPorIdVenta(int idVenta);
    bool listarPorVenta(int idVenta);
    int contarRegistros();
    bool modificarRegistro(DetalleVenta reg, int pos);
};
