#include "Venta.h"
#include "Fecha.h"
#include "FuncionesGenerales.h"
#include <iostream>

using namespace std;
Venta::Venta() {
    _idVenta = 0;
    _idCliente = 0;
    _importeTotal = 0;
    _formaPago =0;
    _estado = false;
}

void Venta::cargar(int idVenta, int idCliente, float importeTotal){

    setIdVenta(idVenta);
    setIdCliente(idCliente);

    Fecha fechaVenta;
    cout << "FECHA: ";
    fechaVenta.cargar();
    while(true){
        cout << "FORMA DE PAGO: ";
        cout << "1. BILLETERA VIRTUAL";
        cout << "2. TARJETA DE CREDITO";
        cout << "3. TARJETA DE DEBITO";
        int formaPago = PedirEnteroValido("INGRESAR: ");
        if(setFormaPago(formaPago)){
            break;
        }

    }
    setEstado(true);

}
void Venta::mostrar() {
    cout << " ID Venta: " << _idVenta << std::endl;
    cout << " Cliente: " << _idCliente << std::endl;
    cout << " Fecha: " << _fechaVenta.toString() << std::endl;
    cout << " Importe: " << _importeTotal << std::endl;
    cout << " Pago: " << getFormaPagoStr() << std::endl;
}

/// getters
int Venta::getIdVenta() { return _idVenta; }
int Venta::getIdCliente() { return _idCliente; }
Fecha Venta::getFechaVenta() { return _fechaVenta; }
float Venta::getImporteTotal() { return _importeTotal; }
int Venta::getFormaPago() {return _formaPago; }
bool Venta::getEstado() { return _estado; }
std::string Venta::getFormaPagoStr() {
    switch (_formaPago) {
        case 1: return "Billetera virtual";
        case 2: return "Tarjeta de d�bito";
        case 3: return "Tarjeta de cr�dito";
        default: return "Desconocido";
    }
}

/// setters
void Venta::setIdVenta(int idVenta) { _idVenta = idVenta; }
void Venta::setIdCliente(int idCliente) { _idCliente = idCliente; }
void Venta::setFechaVenta(Fecha fechaVenta) { _fechaVenta = fechaVenta; }
void Venta::setImporteTotal(float importeTotal) { _importeTotal = importeTotal; }
bool Venta::setFormaPago(int formaPago){
    if(formaPago>=1 && formaPago<=3){
        _formaPago = formaPago;
        return true;
    }
    return false;
}
void Venta::setEstado(bool estado) { _estado = estado; }
