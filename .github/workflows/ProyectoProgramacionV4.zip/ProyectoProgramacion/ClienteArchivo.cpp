#include <iostream>
#include <cstdio>
#include <cstring>
#include "ClienteArchivo.h"
using namespace std;

int ClienteArchivo::altaCliente(long long documento, int tipo) {
    Cliente reg;

    int pos = BuscarPorDocumento(documento);
    if (pos < 0) {
        reg.cargar(documento, tipo);
        reg.setEstado(true);
        if (agregarRegistro(reg) == 1) {
            return 1; // cargado correctamente
        } else {
            return -1; // error al guardar
        }
    }

    Cliente existente = leerRegistro(pos);
    if (!existente.getEstado()) {
        return -2; // Existe pero est� dado de baja
    }

    return 0; // Ya existe y est� activo
}

int ClienteArchivo::agregarRegistro(Cliente reg) {
    FILE* pCliente = fopen(_nombreArchivo, "ab");
    if (pCliente == nullptr) {
        cout << "ERROR DE ARCHIVO";
        return -1;
    }

    int escribio = fwrite(&reg, tamanioRegistro, 1, pCliente);
    fclose(pCliente);

    return escribio;
}

bool ClienteArchivo::listarRegistros() {
    Cliente cliente;
    FILE* pCliente = fopen(_nombreArchivo, "rb");

    if (pCliente == nullptr) {
        return false;
    }

    while (fread(&cliente, tamanioRegistro, 1, pCliente) == 1) {
        if (cliente.getEstado()) {
            cliente.mostrar();
        }
    }

    fclose(pCliente);
    return true;
}

Cliente ClienteArchivo::leerRegistro(int pos) {
    Cliente obj;
    FILE* pCliente = fopen(_nombreArchivo, "rb");

    if (pCliente == nullptr) {
        return obj;
    }

    fseek(pCliente, pos * tamanioRegistro, 0);
    fread(&obj, tamanioRegistro, 1, pCliente);
    fclose(pCliente);

    return obj;
}

bool ClienteArchivo::bajaLogica() {
    Cliente reg;
    cout << "Ingrese el documento del Cliente: ";
    long long documento;
    cin >> documento;

    int pos = BuscarPorDocumento(documento);
    if (pos < 0) {
        return false;
    }

    reg = leerRegistro(pos);
    reg.setEstado(false);

    if (modificarRegistro(reg, pos) == 1) {
        return true;
    }
    return false;
}

int ClienteArchivo::modificarRegistro(Cliente reg, int pos) {
    FILE* pCliente = fopen(_nombreArchivo, "rb+");

    if (pCliente == nullptr) {
        return -1;
    }

    fseek(pCliente, pos * tamanioRegistro, 0);
    int escribio = fwrite(&reg, tamanioRegistro, 1, pCliente);
    fclose(pCliente);

    if (escribio != 1) {
        return -2;
    }

    return 1;
}

int ClienteArchivo::BuscarPorDocumento(long long documentoBuscado) {
    Cliente cliente;
    FILE* pCliente = fopen(_nombreArchivo, "rb");

    if (pCliente == nullptr) {
        return -2;
    }

    int pos = 0;
    while (fread(&cliente, tamanioRegistro, 1, pCliente) == 1) {
        if (cliente.getDocumento() == documentoBuscado) {
            fclose(pCliente);
            return pos;
        }
        pos++;
    }

    fclose(pCliente);
    return -1;
}

void ClienteArchivo::BuscarPorNombre(const char* nombreBuscado) {
    Cliente reg;
    FILE* p = fopen(_nombreArchivo, "rb");

    if (p == nullptr) {
        cout << "ERROR AL ABRIR ARCHIVO\n";
        return;
    }

    while (fread(&reg, tamanioRegistro, 1, p) == 1) {
        if (reg.getEstado() && strcmp(reg.getNombre(), nombreBuscado) == 0) {
            reg.mostrar();
        }
    }

    fclose(p);
}

void ClienteArchivo::BuscarPorApellido(const char* apellidoBuscado) {
    Cliente reg;
    FILE* p = fopen(_nombreArchivo, "rb");

    if (p == nullptr) {
        cout << "ERROR AL ABRIR ARCHIVO\n";
        return;
    }

    while (fread(&reg, tamanioRegistro, 1, p) == 1) {
        if (reg.getEstado() && strcmp(reg.getApellido(), apellidoBuscado) == 0) {
            reg.mostrar();
        }
    }

    fclose(p);
}

int ClienteArchivo::reactivarCliente(long long documento) {
    int pos = BuscarPorDocumento(documento);
    if (pos >= 0) {
        Cliente c = leerRegistro(pos);
        if (c.getEstado()) {
            return 0;
        }
        c.setEstado(true);
        if (modificarRegistro(c, pos) == 1) {
            return 1;
        } else {
            return -1;
        }
    }
    return -2;
}

