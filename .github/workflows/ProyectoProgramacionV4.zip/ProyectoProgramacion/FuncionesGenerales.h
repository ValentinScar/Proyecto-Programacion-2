#pragma once
#include <iostream>
using namespace std;

bool esTextoValido(const char* texto);

bool esEnteroValido(const char* entrada, int& numero);

int PedirEnteroValido(string texto);

long long PedirEnteroValidoLargo(string texto);
