#pragma once
#include <cstring>
#include "Fecha.h"

class Venta {
private:
    int   _idVenta;
    int   _idCliente;
    Fecha _fechaVenta;
    float _importeTotal;
    int  _formaPago;
    bool  _estado;

public:
    Venta();
    void cargar(int idVenta, int idClienet, float importeTotal);
    void mostrar();

    /// getters
    int getIdVenta();
    int getIdCliente();
    Fecha getFechaVenta();
    float getImporteTotal();
    int getFormaPago();
    bool getEstado();

    std::string getFormaPagoStr();

    /// setters
    void setIdVenta(int idVenta);
    void setIdCliente(int idCliente);
    void setFechaVenta(Fecha fechaVenta);
    void setImporteTotal(float importeTotal);
    bool setFormaPago(int formaPago);
    void setEstado(bool estado);
};
