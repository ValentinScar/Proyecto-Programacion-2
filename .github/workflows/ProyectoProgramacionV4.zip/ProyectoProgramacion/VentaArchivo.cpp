#include "VentaArchivo.h"
#include "Venta.h"
#include "cliente.h"
#include "ClienteArchivo.h"
#include "DetalleVentaArchivo.h"
#include "FuncionesGenerales.h"
#include <iostream>

int VentaArchivo::altaVenta() {
    ClienteArchivo archCliente;
    DetalleVentaArchivo archDetalle;
    int documento, tipo;

    tipo = PedirEnteroValido("TIPO CLIENTE: 1. PARTICULAR / 2. EMPRESA ");
    switch (tipo) {
        case 1: documento = PedirEnteroValido("DNI: "); break;
        case 2: documento = PedirEnteroValido("CUIT: "); break;
        default:
            cout << "Opción inválida.\n";
            return -1;
    }

    int posCliente = archCliente.BuscarPorDocumento(documento);
    if (posCliente < 0) {
        cout << "CLIENTE NO ENCONTRADO.\n";
        system("pause");
        return -2;
    }

    Cliente c = archCliente.leerRegistro(posCliente);
    if (!c.getEstado()) {
        cout << "CLIENTE DADO DE BAJA.\n";
        system("pause");
        return -3;
    }

    int idVenta = generarIdVenta();
    float total = archDetalle.altaDetalle(idVenta);  // ← pasás el ID generado

    if (total <= 0) {
        cout << "No se pudo registrar detalle o venta vacía.\n";
        return -3;
    }

    Venta v;
    v.cargar(idVenta, documento, total);
    if (agregarRegistro(v) == 1) {
        cout << "Venta registrada correctamente.\n";
        return 1;
    }

    cout << "Error al guardar venta.\n";
    return 0;
}



bool VentaArchivo::agregarRegistro(Venta reg) {
    FILE* pVenta = fopen(_nombreArchivo, "ab");
    if (pVenta == nullptr) {
        std::cout << "ERROR DE ARCHIVO";
        return false;
    }

    int escribio = fwrite(&reg, tamanioRegistro, 1, pVenta);
    fclose(pVenta);

    return escribio == 1;
}

Venta VentaArchivo::leerRegistro(int pos) {
    Venta obj;
    FILE* pVenta = fopen(_nombreArchivo, "rb");

    obj.setIdVenta(-1);
    if (pVenta == nullptr) {
        return obj;
    }

    fseek(pVenta, pos * tamanioRegistro, 0);
    fread(&obj, tamanioRegistro, 1, pVenta);

    fclose(pVenta);
    return obj;
}

int VentaArchivo::ModificarRegistro(Venta reg, int pos) {
    FILE* pVenta = fopen(_nombreArchivo, "rb+");
    if (pVenta == nullptr) {
        return -1;
    }

    fseek(pVenta, pos * tamanioRegistro, 0);
    int escribio = fwrite(&reg, tamanioRegistro, 1, pVenta);

    fclose(pVenta);
    return escribio;
}

bool VentaArchivo::bajaLogica(int idVenta) {
    Venta reg;
    VentaArchivo archivo(_nombreArchivo);

    int pos = archivo.buscarPorId(idVenta);
    if (pos < 0) {
        return false;
    }

    reg = archivo.leerRegistro(pos);
    reg.setEstado(false);

    return archivo.ModificarRegistro(reg, pos) == 1;
}


int VentaArchivo::buscarPorId(int idVenta) {
    Venta venta;
    FILE* pVenta = fopen(_nombreArchivo, "rb");

    if (pVenta == nullptr) {
        return -2;
    }

    int pos = 0;
    while (fread(&venta, tamanioRegistro, 1, pVenta) == 1) {
        if (venta.getIdVenta() == idVenta) {
            fclose(pVenta);
            return pos;
        }
        pos++;
    }

    fclose(pVenta);
    return -3; // No encontrado
}

bool VentaArchivo::listarRegistros() {
    Venta reg;
    FILE* pVenta = fopen(_nombreArchivo, "rb");

    if (pVenta == nullptr) {
        return false;
    }

    while (fread(&reg, tamanioRegistro, 1, pVenta) == 1) {
        if (reg.getEstado()) {
            reg.mostrar();
        }
    }

    fclose(pVenta);
    return true;
}

int VentaArchivo::contarRegistros() {
    Venta venta;
    FILE* pVenta = fopen(_nombreArchivo, "rb");
    if (pVenta == nullptr) {
        return 0;
    }

    int contador = 0;
    while (fread(&venta, tamanioRegistro, 1, pVenta) == 1) {
        contador++;
    }

    fclose(pVenta);
    return contador;
}

int VentaArchivo::generarIdVenta() {
    return contarRegistros() + 1;
}

