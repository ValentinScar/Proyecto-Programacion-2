#include <iostream>
#include "Menu.h"
#include "rlutil.h"
#include "FuncionesGenerales.h"
#include "cliente.h"
#include "Venta.h"
#include "Producto.h"
#include "ClienteArchivo.h"
#include "ProductoArchivo.h"
#include "VentaArchivo.h"

using namespace std;

long long ValidarDocumentoSegunTipo(int tipo) {
    Cliente c;
    int documento;
    long long documentoLargo;

    switch(tipo) {
        case 1: // Particular
            while(true) {
                documento = PedirEnteroValido("DNI: ");
                if(c.setDni(documento)) break;
                std::cout << "DNI invalido\n";
            }
            return documento;
            break;
        case 2: // Empresa
            while(true) {
                documentoLargo = PedirEnteroValidoLargo("CUIT: ");
                if(c.setCuit(documentoLargo)) break;
                std::cout << "CUIT invalido\n";
            }
            return documentoLargo;
            break;
        default:
            std::cout << "Tipo invalido.\n";
            return -1;
    }

    return documento;
}


int flechaSeleccion(int y, int cantidadOpciones, bool &seleccionar) {
    int tecla = rlutil::getkey();

    switch (tecla) {
        case rlutil::KEY_UP:
            y--;
            if (y < 0) y = cantidadOpciones - 1;
            break;
        case rlutil::KEY_DOWN:
            y++;
            if (y >= cantidadOpciones) y = 0;
            break;
        case rlutil::KEY_ENTER:
            seleccionar = true;
            break;
        default:
            break;
    }
    return y;
}

int mostrarMenuPrincipal() {
    int y = 0;
    const int cantidadOpciones = 4;
    bool seleccionar = false;
    int yAnterior = -1;

    rlutil::cls();
    rlutil::locate(50, 10); cout << "--- MENU PRINCIPAL ---";
    rlutil::locate(55, 11); cout << "MENU CLIENTE";
    rlutil::locate(55, 12); cout << "MENU PRODUCTOS";
    rlutil::locate(55, 13); cout << "MENU VENTAS";
    rlutil::locate(55, 14); cout << "SALIR";

    while (!seleccionar) {
        if (y != yAnterior) {

            if (yAnterior != -1) {
                rlutil::locate(53, 11 + yAnterior);
                cout << " ";
            }

            rlutil::locate(53, 11 + y);
            cout << (char)175;
            yAnterior = y;
        }
        y = flechaSeleccion(y, cantidadOpciones, seleccionar);
    }

    return y;
}

int mostrarMenuCliente() {
    int y = 0;
    const int cantidadOpciones = 5;
    bool seleccionar = false;
    int yAnterior = -1;

    rlutil::cls();
    rlutil::locate(50, 10); cout << "--- MENU CLIENTE ---";
    rlutil::locate(55, 11); cout << " AGREGAR CLIENTE";
    rlutil::locate(55, 12); cout << " BORRAR CLIENTE";
    rlutil::locate(55, 13); cout << " REACTIVAR CLIENTE";
    rlutil::locate(55, 14); cout << " VER CLIENTES";
    rlutil::locate(55, 15); cout << " VOLVER AL MENU PRINCIPAL";

    while (!seleccionar) {
        if (y != yAnterior) {

            if (yAnterior != -1) {
                rlutil::locate(53, 11 + yAnterior);
                cout << " ";
            }

            rlutil::locate(53, 11 + y);
            cout << (char)175;
            yAnterior = y;
        }
        y = flechaSeleccion(y, cantidadOpciones, seleccionar);
    }

    return y;
}

int mostrarMenuProductos() {
    int y = 0;
    const int cantidadOpciones = 4;
    bool seleccionar = false;
    int yAnterior = -1;

    rlutil::cls();
    rlutil::locate(50, 10); cout << "--- MENU PRODUCTOS ---";
    rlutil::locate(55, 11); cout << " AGREGAR PRODUCTO";
    rlutil::locate(55, 12); cout << " BORRAR PRODUCTO";
    rlutil::locate(55, 13); cout << " VER PRODUCTOS";
    rlutil::locate(55, 14); cout << " VOLVER AL MENU PRINCIPAL";

    while (!seleccionar) {
        if (y != yAnterior) {

            if (yAnterior != -1) {
                rlutil::locate(53, 11 + yAnterior);
                cout << " ";
            }

            rlutil::locate(53, 11 + y);
            cout << (char)175;
            yAnterior = y;
        }
        y = flechaSeleccion(y, cantidadOpciones, seleccionar);
    }

    return y;
}

int mostrarMenuVentas() {
    int y = 0;
    const int cantidadOpciones = 4;
    bool seleccionar = false;
    int yAnterior = -1;

    rlutil::cls();
    rlutil::locate(50, 10); cout << "--- MENU VENTAS ---";
    rlutil::locate(55, 11); cout << " NUEVA VENTA";
    rlutil::locate(55, 12); cout << " VER VENTAS";
    rlutil::locate(55, 13); cout << " BUSCAR VENTA";
    rlutil::locate(55, 14); cout << " VOLVER AL MENU PRINCIPAL";

    while (!seleccionar) {
        if (y != yAnterior) {
            // Borrar flecha anterior
            if (yAnterior != -1) {
                rlutil::locate(53, 11 + yAnterior);
                cout << " ";
            }
            // Dibujar flecha nueva
            rlutil::locate(53, 11 + y);
            cout << (char)175;
            yAnterior = y;
        }
        y = flechaSeleccion(y, cantidadOpciones, seleccionar);
    }

    return y;
}


int menuLogicoCliente() {
    int opcion;
    ClienteArchivo cA;
    Cliente c;

    do {
        opcion = mostrarMenuCliente();

        switch (opcion) {
            case 0: {
                system("cls");
                cout << "Agregar cliente...\n";
                cout << "--------------------------\n";

                int tipo = PedirEnteroValido("Tipo cliente: 1. Particular / 2. Empresa: ");
                long long documento = ValidarDocumentoSegunTipo(tipo);
                if(documento > 0) {
                    cA.altaCliente(documento, tipo);
                }
                break;
            }
            case 1: {
                system("cls");
                cout << "Borrar cliente...\n";
                cout << "--------------------------\n";
                cA.bajaLogica();
                system("pause");
                break;
            }
            case 2: {
                system("cls");
                cout << "Reactivar cliente...\n";
                cout << "--------------------------\n";
                int tipo = PedirEnteroValido("Tipo cliente: 1. Particular / 2. Empresa: ");
                long long documento = ValidarDocumentoSegunTipo(tipo);
                if(documento > 0) {
                    int exito = cA.reactivarCliente(documento);
                    switch(exito){
                        case 0:
                            cout << "Ya esta activo"<<endl;
                            break;
                        case 1:
                            cout << "Reactivado"<<endl;
                            break;
                        case -1:
                            cout << "Error al guardar"<<endl;
                            break;
                        case -2:
                            cout << "Cliente no encontrado"<<endl;
                            break;
                    }

                    system("pause");
                }
                break;
            }
            case 3: {
                system("cls");
                cout << "CLIENTES\n";
                cout << "---------------------------------\n";
                cA.listarRegistros();
                system("pause");
                break;
            }
            case 4:
                cout << "Volviendo al menu principal...\n";
                break;
            default:
                cout << "Opcion invalida\n";
                system("pause");
        }
    } while (opcion != 4);

    return 0;
}

int menuLogicoProductos(){
    int opcion;
    ProductoArchivo pA;
    Producto p;

    do {
        opcion = mostrarMenuProductos();

        switch (opcion) {
            case 0: {
                system("cls");
                cout << "Agregar Producto...\n";
                cout << "--------------------------\n";
                pA.altaProducto();
                break;
            }
            case 1: {
                system("cls");
                cout << "Borrar producto...\n";
                pA.bajaLogica();
                system("pause");
                break;
            }
            case 2: {
                system("cls");
                cout << "PRODUCTOS\n";
                cout << "---------------------------------\n";
                pA.listarRegistros();
                system("pause");
                break;
            }
            case 3:  // VOLVER
                cout << "Volviendo al menu principal...\n";
                break;
            default:
                cout << "Opcion invalida\n";
                system("pause");
        }
    } while (opcion != 3);

    return 0;
}

int menuLogicoVentas(){
    int opcion;
    VentaArchivo pV;

    do {
        opcion = mostrarMenuVentas();

        switch (opcion) {
            case 0: {
                system("cls");
                cout << "Agregar Venta...\n";
                cout << "--------------------------\n";
                pV.altaVenta();
                break;
            }
            case 1: {
                system("cls");
                cout << "Borrar venta...\n";
                int idVenta = PedirEnteroValido("INGRESE EL ID DE LA VENTA A BORRAR: ");
                pV.bajaLogica(idVenta);
                system("pause");
                break;
            }
            case 2: {
                system("cls");
                cout << "PRODUCTOS\n";
                cout << "---------------------------------\n";
                pV.listarRegistros();
                system("pause");
                break;
            }
            case 3:  // VOLVER
                cout << "Volviendo al menu principal...\n";
                break;
            default:
                cout << "Opcion invalida\n";
                system("pause");
        }
    } while (opcion != 3);

    return 0;
}
