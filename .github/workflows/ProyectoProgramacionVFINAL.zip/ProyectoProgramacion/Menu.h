#pragma once
#include <string>
using namespace std;

int flechaSeleccion(int y, int cantidadOpciones, bool &seleccionar);

int mostrarMenuPrincipal();
int mostrarMenuCliente();
int mostrarMenuProductos();
int mostrarMenuVentas();

int menuLogicoCliente();
int menuLogicoProductos();
int menuLogicoVentas();

long long ValidarDocumentoSegunTipo(int tipo);


