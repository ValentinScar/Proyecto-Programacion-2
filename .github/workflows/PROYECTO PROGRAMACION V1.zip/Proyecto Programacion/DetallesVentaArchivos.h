#pragma once
#include <cstdio>
#include <cstring>
#include "DetallesVenta.h"

class DetalleVentasArchivo {
private:
    char _NombreArch[32];
public:
    DetalleVentasArchivo(const char* filename = "DetalleVentas.dat") {
        std::strcpy(_NombreArch, filename);
    }
    const char* getFilename() { return _NombreArch; }

    bool guardar(const DetalleVentas& reg);
    bool leer(int pos, DetalleVentas& out);
    int contarRegistros();
    bool sobrescribir(int pos, const DetalleVentas& reg);
}
;
