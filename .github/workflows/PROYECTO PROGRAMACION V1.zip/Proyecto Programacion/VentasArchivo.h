#pragma once
#include <cstdio>
#include <cstring>
#include "Ventas.h"
#include <cstring>
class VentasArchivo {
private:
    char _NombreArch[32];

public:

    VentasArchivo(const char* filename = "Ventas.dat") {
        std::strcpy(_NombreArch, filename);
    }

    const char* getFilename() { return _NombreArch; }


    bool guardar(const Venta& reg);
    bool leer(int pos, Venta& out);
    int  contarRegistros();
    bool sobrescribir(int pos, const Venta& r);

};
