#pragma once
#include <iostream>
#include <cstring>

class Productos {
private:
    int _idProducto;
    int _TipoEquipo;
    int _stock;
    char _descripcion[50];
    char _marca[30];
    bool _estado;

public:
    Productos();
    //getters
    int getIdProducto();
    char* getDescripcion();
    char* getMarca();
    int getTipoEquipo();
    bool getEstado();

    std::string getTipoEquipo(int tipoEquipo);

    // Setters
    bool setIdProducto(int id);
    void setDescripcion(char* desc);
    bool setMarca(char* marca);
    bool setTipoEquipo(int tipoEquipo);
    void setEstado(bool estado);
    void Cargar();
    void mostrar();
};
