#pragma once
#include <cstring>
#include "Fecha.h"

class Compras {
private:
    int _idCompra;
    int _idProveedor;
    int _idEmpleado;
    Fecha _fechaCompra;
    char _estadoCompra[20];
    float _importe;
    bool _eliminado;

public:
    Compras() {
        _idCompra = 0;
        _idProveedor = 0;
        _idEmpleado = 0;
        std::strcpy(_estadoCompra, "");
        _importe = 0;
        _eliminado = false;
    }

    Compras(int idCompra, int idProveedor, int idEmpleado, Fecha fechaCompra,
            const char* estadoCompra, float importe, bool eliminado) {
        _idCompra = idCompra;
        _idProveedor = idProveedor;
        _idEmpleado = idEmpleado;
        _fechaCompra = fechaCompra;
        std::strcpy(_estadoCompra, estadoCompra);
        _importe = importe;
        _eliminado = eliminado;
    }

    int getIdCompra() { return _idCompra; }
    void setIdCompra(int v) { _idCompra = v; }

    int getIdProveedor() { return _idProveedor; }
    void setIdProveedor(int v) { _idProveedor = v; }

    int getIdEmpleado() { return _idEmpleado; }
    void setIdEmpleado(int v) { _idEmpleado = v; }

    Fecha getFechaCompra() { return _fechaCompra; }
    void setFechaCompra(Fecha v) { _fechaCompra = v; }

    const char* getEstadoCompra() { return _estadoCompra; }
    void setEstadoCompra(const char* v) { std::strcpy(_estadoCompra, v); }

    float getImporte() { return _importe; }
    void setImporte(float v) { _importe = v; }

    bool getEliminado() { return _eliminado; }
    void setEliminado(bool v) { _eliminado = v; }
}
;
