#include "ComprasArchivos.h"

bool ComprasArchivo::guardar(const Compras& reg) {
    FILE* p = std::fopen(_NombreArch, "ab");
    if (!p) return false;
    bool ok = std::fwrite(&reg, sizeof(Compras), 1, p) == 1;
    std::fclose(p);
    return ok;
}

bool ComprasArchivo::leer(int pos, Compras& out) {
    FILE* p = std::fopen(_NombreArch, "rb");
    if (!p) return false;
    std::fseek(p, pos * (int)sizeof(Compras), SEEK_SET);
    bool ok = std::fread(&out, sizeof(Compras), 1, p) == 1;
    std::fclose(p);
    return ok;
}

int ComprasArchivo::contarRegistros() {
    FILE* p = std::fopen(_NombreArch, "rb");
    if (!p) return 0;
    std::fseek(p, 0, SEEK_END);
    long bytes = std::ftell(p);
    std::fclose(p);
    return (int)(bytes / (long)sizeof(Compras));
}

bool ComprasArchivo::sobrescribir(int pos, const Compras& reg) {
    FILE* p = std::fopen(_NombreArch, "rb+");
    if (!p) return false;
    std::fseek(p, pos * (int)sizeof(Compras), SEEK_SET);
    bool ok = std::fwrite(&reg, sizeof(Compras), 1, p) == 1;
    std::fclose(p);
    return ok;
}
