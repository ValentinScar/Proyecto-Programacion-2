#pragma once
#include <cstdio>
#include <cstring>
#include "TiposDeEquipo.h"


class TiposDeEquipoArchivo {
private:
char _NombreArch[32];
public:
TiposDeEquipoArchivo(const char* Nombre = "TiposDeEquipo.dat") {
std::strcpy(_NombreArch, Nombre);
}
const char* getNombre() { return _NombreArch; }


bool guardar(const TiposDeEquipo& reg);
bool leer(int pos, TiposDeEquipo& out);
int contarRegistros();
bool sobrescribir(int pos, const TiposDeEquipo& reg);
};
