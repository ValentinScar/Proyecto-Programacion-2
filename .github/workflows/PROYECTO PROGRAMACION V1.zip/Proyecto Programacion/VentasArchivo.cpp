#include "VentasArchivo.h"

bool VentasArchivo::guardar(const Venta& reg) {
    FILE* p = std::fopen(_NombreArch, "ab");
    if (!p) return false;
    bool ok = std::fwrite(&reg, sizeof(Venta), 1, p) == 1;
    std::fclose(p);
    return ok;
}

bool VentasArchivo::leer(int pos, Venta& out) {
    if (pos < 0) return false;
    FILE* p = std::fopen(_NombreArch, "rb");
    if (!p) return false;
    std::fseek(p, pos * (int)sizeof(Venta), SEEK_SET);
    bool ok = std::fread(&out, sizeof(Venta), 1, p) == 1;
    std::fclose(p);
    return ok;
}

int VentasArchivo::contarRegistros() {
    FILE* p = std::fopen(_NombreArch, "rb");
    if (!p) return 0;
    std::fseek(p, 0, SEEK_END);
    long bytes = std::ftell(p);
    std::fclose(p);
    return (int)(bytes / (long)sizeof(Venta));
}

bool VentasArchivo::sobrescribir(int pos, const Venta& r) {
    if (pos < 0) return false;
    FILE* p = std::fopen(_NombreArch, "rb+");
    if (!p) return false;
    std::fseek(p, pos * (int)sizeof(Venta), SEEK_SET);
    bool ok = std::fwrite(&r, sizeof(Venta), 1, p) == 1;
    std::fclose(p);
    return ok;
}
