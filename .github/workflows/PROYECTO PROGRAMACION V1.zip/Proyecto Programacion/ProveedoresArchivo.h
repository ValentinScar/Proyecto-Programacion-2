#pragma once
#include <cstdio>
#include <cstring>
#include "Proveedores.h"

class ProveedoresArchivo {
private:
    char _NombreArch[32];
public:
    ProveedoresArchivo(const char* filename = "Proveedores.dat") {
        std::strcpy(_NombreArch, filename);
    }
    const char* getFilename() { return _NombreArch; }

    bool guardar(const Proveedores& reg);
    bool leer(int pos, Proveedores& out);
    int contarRegistros();
    bool sobrescribir(int pos, const Proveedores& reg);
}
;
