#include <iostream>
#include "MenuProductos.h"
#include "MenuVentas.h"
using namespace std;



void MenuManager() {
int Opcion;

do{
  cout << "===============================" << endl;
  cout << "       SISTEMA DE GESTION      " << endl;
  cout << "===============================" << endl;
  cout << endl;
  cout << "1. MENU VENTAS" << endl;
  cout << "2. MENU PRODUCTOS" << endl;
  cout << "0. SALIR" << endl;

  cin >> Opcion;
  cin.ignore();


  switch(Opcion){
   case 1: MenuVentas(); break;
   case 2: MenuProductos(); break;
   case 0: cout << "SALIENDO DEL SISTEMA... " << endl; break;
   default: cout << "OPCION INCORRECTA" << endl; break;
  }
  cout << endl;
} while(Opcion!=0);




}
