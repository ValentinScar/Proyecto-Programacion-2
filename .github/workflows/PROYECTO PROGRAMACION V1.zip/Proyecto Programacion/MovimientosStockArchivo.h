#pragma once
#include <cstdio>
#include <cstring>
#include "MoviemientoStock.h"

class MovimientosStockArchivo {
private:
    char _NombreArch[32];
public:
    MovimientosStockArchivo(const char* filename = "MovimientosStock.dat") {
        std::strcpy(_NombreArch, filename);
    }
    const char* getFilename() { return _NombreArch; }

    bool guardar(const MovimientosStock& reg);
    bool leer(int pos, MovimientosStock& out);
    int contarRegistros();
    bool sobrescribir(int pos, const MovimientosStock& reg);
}
;
