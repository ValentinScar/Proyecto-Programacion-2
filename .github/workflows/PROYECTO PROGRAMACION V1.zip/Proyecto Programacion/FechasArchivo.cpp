#include "FechaArchivo.h"

bool FechaArchivo::guardar(const Fecha& reg) {
    FILE* p = std::fopen(_NombreArch, "ab");
    if (!p) return false;
    bool ok = std::fwrite(&reg, sizeof(Fecha), 1, p) == 1;
    std::fclose(p);
    return ok;
}

bool FechaArchivo::leer(int pos, Fecha& out) {
    FILE* p = std::fopen(_NombreArch, "rb");
    if (!p) return false;
    std::fseek(p, pos * (int)sizeof(Fecha), SEEK_SET);
    bool ok = std::fread(&out, sizeof(Fecha), 1, p) == 1;
    std::fclose(p);
    return ok;
}

int FechaArchivo::contarRegistros() {
    FILE* p = std::fopen(_NombreArch, "rb");
    if (!p) return 0;
    std::fseek(p, 0, SEEK_END);
    long bytes = std::ftell(p);
    std::fclose(p);
    return (int)(bytes / (long)sizeof(Fecha));
}

bool FechaArchivo::sobrescribir(int pos, const Fecha& reg) {
    FILE* p = std::fopen(_NombreArch, "rb+");
    if (!p) return false;
    std::fseek(p, pos * (int)sizeof(Fecha), SEEK_SET);
    bool ok = std::fwrite(&reg, sizeof(Fecha), 1, p) == 1;
    std::fclose(p);
    return ok;
}
