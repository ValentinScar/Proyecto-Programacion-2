#pragma once
#include <cstring>


class TiposDeEquipo {
private:
int _idTipoEquipo;
char _descripcion[30];


public:
TiposDeEquipo() {
_idTipoEquipo = 0;
std::strcpy(_descripcion, "");
}

TiposDeEquipo(int idTipoEquipo, const char* descripcion) {
_idTipoEquipo = idTipoEquipo;
std::strcpy(_descripcion, descripcion);
}

int getIdTipoEquipo() { return _idTipoEquipo; }
void setIdTipoEquipo(int v) { _idTipoEquipo = v; }

const char* getDescripcion() { return _descripcion; }
void setDescripcion(const char* v) { std::strcpy(_descripcion, v); }
};
