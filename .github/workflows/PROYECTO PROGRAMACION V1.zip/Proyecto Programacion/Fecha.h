#pragma once

class Fecha {
private:
    int _dia;
    int _mes;
    int _anio;

public:
    Fecha() {
        _dia = 0;
        _mes = 0;
        _anio = 0;
    }
    Fecha(int dia, int mes, int anio) {
        _dia = dia;
        _mes = mes;
        _anio = anio;
    }

    int getDia() { return _dia; }
    void setDia(int v) { _dia = v; }

    int getMes() { return _mes; }
    void setMes(int v) { _mes = v; }

    int getAnio() { return _anio; }
    void setAnio(int v) { _anio = v; }
}
;
