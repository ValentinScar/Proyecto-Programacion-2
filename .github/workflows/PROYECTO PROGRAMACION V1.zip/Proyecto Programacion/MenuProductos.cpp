#include <iostream>
#include "MenuProductos.h"
#include "FuncionesProductos.h"

using namespace std;

void MenuProductos() {
    int op;
    do {
        cout << "=========== MENU PRODUCTOS ===========\n";
        cout << "1) CARGAR PRODUCTO\n";
        cout << "2) LISTAR PRODUCTOS\n";
        cout << "3) DAR DE BAJA PRODUCTO\n";
        cout << "0) Volver\n";
        cout << "Opcion: ";
        cin >> op;
        cin.ignore();

        switch (op) {
            case 1: CargarProducto();   break;
            case 2: ListarProductos();  break;
            case 3: EliminarProducto(); break;
            case 0: break;
            default: cout << "Opcion invalida.\n"; break;
        }
        cout << "\n";
    } while (op != 0);
}
