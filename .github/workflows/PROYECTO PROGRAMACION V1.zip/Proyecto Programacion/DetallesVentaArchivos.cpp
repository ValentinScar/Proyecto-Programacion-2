#include "DetallesVentaArchivos.h"

bool DetalleVentasArchivo::guardar(const DetalleVentas& reg) {
    FILE* p = std::fopen(_NombreArch, "ab");
    if (!p) return false;
    bool ok = std::fwrite(&reg, sizeof(DetalleVentas), 1, p) == 1;
    std::fclose(p);
    return ok;
}

bool DetalleVentasArchivo::leer(int pos, DetalleVentas& out) {
    FILE* p = std::fopen(_NombreArch, "rb");
    if (!p) return false;
    std::fseek(p, pos * (int)sizeof(DetalleVentas), SEEK_SET);
    bool ok = std::fread(&out, sizeof(DetalleVentas), 1, p) == 1;
    std::fclose(p);
    return ok;
}

int DetalleVentasArchivo::contarRegistros() {
    FILE* p = std::fopen(_NombreArch, "rb");
    if (!p) return 0;
    std::fseek(p, 0, SEEK_END);
    long bytes = std::ftell(p);
    std::fclose(p);
    return (int)(bytes / (long)sizeof(DetalleVentas));
}

bool DetalleVentasArchivo::sobrescribir(int pos, const DetalleVentas& reg) {
    FILE* p = std::fopen(_NombreArch, "rb+");
    if (!p) return false;
    std::fseek(p, pos * (int)sizeof(DetalleVentas), SEEK_SET);
    bool ok = std::fwrite(&reg, sizeof(DetalleVentas), 1, p) == 1;
    std::fclose(p);
    return ok;
}
