#pragma once

class DetalleCompras {
private:
    int _idDetalleCompra;
    int _idCompra;
    int _idProducto;
    int _cantidad;
    float _costoUnitario;

public:
    DetalleCompras() {
        _idDetalleCompra = 0;
        _idCompra = 0;
        _idProducto = 0;
        _cantidad = 0;
        _costoUnitario = 0;
    }

    DetalleCompras(int idDetalleCompra, int idCompra, int idProducto, int cantidad, float costoUnitario) {
        _idDetalleCompra = idDetalleCompra;
        _idCompra = idCompra;
        _idProducto = idProducto;
        _cantidad = cantidad;
        _costoUnitario = costoUnitario;
    }

    int getIdDetalleCompra() { return _idDetalleCompra; }
    void setIdDetalleCompra(int v) { _idDetalleCompra = v; }

    int getIdCompra() { return _idCompra; }
    void setIdCompra(int v) { _idCompra = v; }

    int getIdProducto() { return _idProducto; }
    void setIdProducto(int v) { _idProducto = v; }

    int getCantidad() { return _cantidad; }
    void setCantidad(int v) { _cantidad = v; }

    float getCostoUnitario() { return _costoUnitario; }
    void setCostoUnitario(float v) { _costoUnitario = v; }
}
;
