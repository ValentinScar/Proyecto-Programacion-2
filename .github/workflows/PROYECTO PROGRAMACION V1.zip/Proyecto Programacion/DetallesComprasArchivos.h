#pragma once
#include <cstdio>
#include <cstring>
#include "DetallesCompra.h"

class DetalleComprasArchivo {
private:
    char _NombreArch[32];
public:
    DetalleComprasArchivo(const char* filename = "DetalleCompras.dat") {
        std::strcpy(_NombreArch, filename);
    }
    const char* getFilename() { return _NombreArch; }

    bool guardar(const DetalleCompras& reg);
    bool leer(int pos, DetalleCompras& out);
    int contarRegistros();
    bool sobrescribir(int pos, const DetalleCompras& reg);
}
;
