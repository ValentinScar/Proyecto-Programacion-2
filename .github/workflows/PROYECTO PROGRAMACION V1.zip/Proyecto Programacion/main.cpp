#include <iostream>
#include "MenuManagger.h"
using namespace std;

int main()
{
	MenuManager();
}
