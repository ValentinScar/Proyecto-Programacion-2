#pragma once
#include <cstring>
#include "Fecha.h"

class Venta {
private:
    int   _idVenta;
    int   _idCliente;
    int   _idEmpleado;
    Fecha _fechaVenta;
    int   _idProducto;
    int   _cantidad;
    float _precioUnitario;
    float _importe;
    char  _formaPago[20];
    bool  _eliminado;

public:
    Venta();
    Venta(int idVenta, int idCliente, int idEmpleado, Fecha fechaVenta,
          int idProducto, int cantidad, float precioUnitario,
          const char* formaPago, bool eliminado);

    void cargar();
    void mostrar();
    int getIdVenta();
    void setIdVenta(int v);

    int getIdCliente();
    void setIdCliente(int v);

    int getIdEmpleado();
    void setIdEmpleado(int v);

    Fecha getFechaVenta();
    void setFechaVenta(Fecha v);

    int getIdProducto();
    void setIdProducto(int v);

    int getCantidad();
    void setCantidad(int v);

    float getPrecioUnitario();
    void setPrecioUnitario(float v);

    float getImporte();
    void setImporte(float v);

    const char* getFormaPago();
    void setFormaPago(const char* v);

    bool getEliminado();
    void setEliminado(bool v);
};
