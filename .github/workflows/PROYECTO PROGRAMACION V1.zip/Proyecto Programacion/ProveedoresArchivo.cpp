#include "ProveedoresArchivo.h"

bool ProveedoresArchivo::guardar(const Proveedores& reg) {
    FILE* p = std::fopen(_NombreArch, "ab");
    if (!p) return false;
    bool ok = std::fwrite(&reg, sizeof(Proveedores), 1, p) == 1;
    std::fclose(p);
    return ok;
}

bool ProveedoresArchivo::leer(int pos, Proveedores& out) {
    FILE* p = std::fopen(_NombreArch, "rb");
    if (!p) return false;
    std::fseek(p, pos * (int)sizeof(Proveedores), SEEK_SET);
    bool ok = std::fread(&out, sizeof(Proveedores), 1, p) == 1;
    std::fclose(p);
    return ok;
}

int ProveedoresArchivo::contarRegistros() {
    FILE* p = std::fopen(_NombreArch, "rb");
    if (!p) return 0;
    std::fseek(p, 0, SEEK_END);
    long bytes = std::ftell(p);
    std::fclose(p);
    return (int)(bytes / (long)sizeof(Proveedores));
}

bool ProveedoresArchivo::sobrescribir(int pos, const Proveedores& reg) {
    FILE* p = std::fopen(_NombreArch, "rb+");
    if (!p) return false;
    std::fseek(p, pos * (int)sizeof(Proveedores), SEEK_SET);
    bool ok = std::fwrite(&reg, sizeof(Proveedores), 1, p) == 1;
    std::fclose(p);
    return ok;
}
