#include <iostream>
#include "FuncionesMenuVentas.h"
#include "Ventas.h"
#include "VentasArchivo.h"
using namespace std;

void CargarVenta() {
    Venta v;
    v.cargar();

    VentasArchivo arch;
    if (arch.guardar(v)) {
        cout << "Venta guardada correctamente. ID: " << v.getIdVenta() << endl;
    } else {
        cout << "Error al guardar la venta." << endl;
    }
}


void ListarVentas() {
    VentasArchivo arch;
    Venta v;
    int cantidad = arch.contarRegistros();

    if (cantidad == 0) {
        cout << "No hay ventas registradas.\n";
        return;
    }

    cout << "====== LISTADO DE VENTAS ======\n";
    for (int i = 0; i < cantidad; i++) {
        if (arch.leer(i, v)) {
            v.mostrar();
        }
                if (!v.getEliminado()) {
                v.mostrar();
            }
        }
    }

void RecaudacionPorAnio() {
    int anio;
    cout << "Ingrese a�o: ";
    cin >> anio;

    VentasArchivo arch;
    Venta v;
    int cantidad = arch.contarRegistros();
    float total = 0;

    for (int i = 0; i < cantidad; i++) {
        if (arch.leer(i, v) && !v.getEliminado() && v.getFechaVenta().getAnio() == anio) {
            total += v.getImporte();
        }
    }


    cout << "Recaudaci�n total del a�o " << anio << ": $" << total << endl;
}
void RecaudacionPorMes() {
    int anio, mes;
    cout << "Ingrese anio: ";
    cin >> anio;
    cout << "Ingrese mes (1-12): ";
    cin >> mes;

    if (mes < 1 || mes > 12) {
        cout << "Mes invalido.\n";
        return;
    }

    VentasArchivo arch;
    Venta v;
    int n = arch.contarRegistros();
    float total = 0;

    for (int i = 0; i < n; i++) {
        if (arch.leer(i, v)) {
            if (!v.getEliminado()
                && v.getFechaVenta().getAnio() == anio
                && v.getFechaVenta().getMes()  == mes) {
                total += v.getImporte();
            }
        }
    }


    cout << "Recaudacion de " << mes << "/" << anio << ": $" << total << "\n";
}
void BuscarVentasPorCliente() {
    int idCliente;
    cout << "Ingrese el ID del cliente: ";
    cin >> idCliente;

    VentasArchivo arch;
    Venta v;
    int cantidad = arch.contarRegistros();
    bool encontrado = false;

    cout << "===========================================\n";
    cout << "Ventas del cliente con ID " << idCliente << ":\n";
    cout << "===========================================\n";

    for (int i = 0; i < cantidad; i++) {
        if (arch.leer(i, v)) {
            if (!v.getEliminado() && v.getIdCliente() == idCliente) {
                v.mostrar();
                encontrado = true;
            }
        }
    }

    if (!encontrado) {
        cout << "No se encontraron ventas para ese cliente.\n";
    }
}
void ModificarFormaPagoPorID() {
    int idBuscar;
    cout << "Ingrese el ID de la venta a modificar: ";
    cin >> idBuscar;

    VentasArchivo arch;
    Venta v;
    int cantidad = arch.contarRegistros();
    bool encontrado = false;

    for (int i = 0; i < cantidad; i++) {
        if (arch.leer(i, v)) {
            if (v.getIdVenta() == idBuscar && !v.getEliminado()) {
                cout << "Venta encontrada:\n";
                v.mostrar();

                cout << "\nIngrese nueva forma de pago: ";
                cin.ignore();
                char nuevaForma[20];
                cin.getline(nuevaForma, 20);

                v.setFormaPago(nuevaForma);

                if (arch.sobrescribir(i, v)) {
                    cout << "Forma de pago modificada correctamente.\n";
                } else {
                    cout << "Error al guardar la modificacion.\n";
                }

                encontrado = true;
                return;
            }
        }
    }

    if (!encontrado) {
        cout << "No se encontro una venta con ese ID.\n";
    }
}
void EliminarVenta(){
int idBuscar;
    cout << "Ingrese el ID de la venta a eliminar: ";
    cin >> idBuscar;

    VentasArchivo arch;
    Venta v;
    int cantidad = arch.contarRegistros();
    bool encontrado = false;

    for (int i = 0; i < cantidad; i++) {
        if (arch.leer(i, v)) {
            if (v.getIdVenta() == idBuscar) {
                encontrado = true;
                if (v.getEliminado()) {
                    cout << "La venta ya fue eliminada previamente.\n";
                    break;
                }

                cout << "Venta encontrada:\n";
                v.mostrar();

                cout << "\nConfirma baja logica? (s/n): ";
                char resp;
                cin >> resp;
                if (resp == 's' || resp == 'S') {
                    v.setEliminado(true);
                    if (arch.sobrescribir(i, v)) {
                        cout << "Venta dada de baja (logica) correctamente.\n";
                    } else {
                        cout << "Error al dar de baja la venta.\n";
                    }
                } else {
                    cout << "Operacion cancelada.\n";
                }
                break;
            }
        }
}
}
