#include "DetallesComprasArchivos.h"

bool DetalleComprasArchivo::guardar(const DetalleCompras& reg) {
    FILE* p = std::fopen(_NombreArch, "ab");
    if (!p) return false;
    bool ok = std::fwrite(&reg, sizeof(DetalleCompras), 1, p) == 1;
    std::fclose(p);
    return ok;
}

bool DetalleComprasArchivo::leer(int pos, DetalleCompras& out) {
    FILE* p = std::fopen(_NombreArch, "rb");
    if (!p) return false;
    std::fseek(p, pos * (int)sizeof(DetalleCompras), SEEK_SET);
    bool ok = std::fread(&out, sizeof(DetalleCompras), 1, p) == 1;
    std::fclose(p);
    return ok;
}

int DetalleComprasArchivo::contarRegistros() {
    FILE* p = std::fopen(_NombreArch, "rb");
    if (!p) return 0;
    std::fseek(p, 0, SEEK_END);
    long bytes = std::ftell(p);
    std::fclose(p);
    return (int)(bytes / (long)sizeof(DetalleCompras));
}

bool DetalleComprasArchivo::sobrescribir(int pos, const DetalleCompras& reg) {
    FILE* p = std::fopen(_NombreArch, "rb+");
    if (!p) return false;
    std::fseek(p, pos * (int)sizeof(DetalleCompras), SEEK_SET);
    bool ok = std::fwrite(&reg, sizeof(DetalleCompras), 1, p) == 1;
    std::fclose(p);
    return ok;
}
