#pragma once
#include <cstring>
#include "Fecha.h"

class MovimientosStock {
private:
    int _idMovimiento;
    int _idProducto;
    Fecha _fecha;
    char _tipoMovimiento[20];
    int _cantidad;
    char _motivo[50];

public:
    MovimientosStock() {
        _idMovimiento = 0;
        _idProducto = 0;
        _cantidad = 0;
        std::strcpy(_tipoMovimiento, "");
        std::strcpy(_motivo, "");
    }

    MovimientosStock(int idMovimiento, int idProducto, Fecha fecha,
                     const char* tipoMovimiento, int cantidad, const char* motivo) {
        _idMovimiento = idMovimiento;
        _idProducto = idProducto;
        _fecha = fecha;
        std::strcpy(_tipoMovimiento, tipoMovimiento);
        _cantidad = cantidad;
        std::strcpy(_motivo, motivo);
    }

    int getIdMovimiento() { return _idMovimiento; }
    void setIdMovimiento(int v) { _idMovimiento = v; }

    int getIdProducto() { return _idProducto; }
    void setIdProducto(int v) { _idProducto = v; }

    Fecha getFecha() { return _fecha; }
    void setFecha(Fecha v) { _fecha = v; }

    const char* getTipoMovimiento() { return _tipoMovimiento; }
    void setTipoMovimiento(const char* v) { std::strcpy(_tipoMovimiento, v); }

    int getCantidad() { return _cantidad; }
    void setCantidad(int v) { _cantidad = v; }

    const char* getMotivo() { return _motivo; }
    void setMotivo(const char* v) { std::strcpy(_motivo, v); }
}
;
