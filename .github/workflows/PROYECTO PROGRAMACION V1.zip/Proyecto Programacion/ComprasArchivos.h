#pragma once
#include <cstdio>
#include <cstring>
#include "Compras.h"

class ComprasArchivo {
private:
    char _NombreArch[32];
public:
    ComprasArchivo(const char* filename = "Compras.dat") {
        std::strcpy(_NombreArch, filename);
    }
    const char* getFilename() { return _NombreArch; }

    bool guardar(const Compras& reg);
    bool leer(int pos, Compras& out);
    int contarRegistros();
    bool sobrescribir(int pos, const Compras& reg);
}
;
