#pragma once
#include <cstdio>
#include <cstring>
#include "Fecha.h"

class FechaArchivo {
private:
    char _NombreArch[32];
public:
    FechaArchivo(const char* filename = "Fecha.dat") {
        std::strcpy(_NombreArch, filename);
    }
    const char* getFilename() { return _NombreArch; }

    bool guardar(const Fecha& reg);
    bool leer(int pos, Fecha& out);
    int contarRegistros();
    bool sobrescribir(int pos, const Fecha& reg);
}
;
