#include "Ventas.h"
#include "VentasArchivo.h"
#include <cstring>
#include <iostream>
using namespace std;
Venta::Venta() {
    _idVenta = 0;
    _idCliente = 0;
    _idEmpleado = 0;
    _idProducto = 0;
    _cantidad = 0;
    _precioUnitario = 0;
    _importe = 0;
    std::strcpy(_formaPago, "");
    _eliminado = false;
}

Venta::Venta(int idVenta, int idCliente, int idEmpleado, Fecha fechaVenta,
             int idProducto, int cantidad, float precioUnitario,
             const char* formaPago, bool eliminado) {
    _idVenta = idVenta;
    _idCliente = idCliente;
    _idEmpleado = idEmpleado;
    _fechaVenta = fechaVenta;
    _idProducto = idProducto;
    _cantidad = cantidad;
    _precioUnitario = precioUnitario;
    _importe = cantidad * precioUnitario;
    std::strcpy(_formaPago, formaPago);
    _eliminado = eliminado;
}
void Venta::cargar() {
    VentasArchivo arch;


    cout << "ID Cliente: ";
    cin >> _idCliente;
    if (_idCliente < 0){
        cout << "El id del cliente no puede ser menor a 0.";
        return;
    }
    cout << "ID Empleado: ";
    cin >> _idEmpleado;
 if (_idEmpleado < 0){
        cout << "El id del empleado no puede ser menor a 0.";
        return;
    }
    int d, m, a;
    cout << "Fecha (dd mm aaaa): ";
    cin >> d >> m >> a;
    _fechaVenta.setDia(d);
    _fechaVenta.setMes(m);
    _fechaVenta.setAnio(a);

    cout << "ID Producto: ";
    cin >> _idProducto;
     if (_idProducto < 0){
        cout << "El id del producto no puede ser menor a 0.";
        return;
    }
    cout << "Cantidad: ";
    cin >> _cantidad;
     if (_cantidad < 1){
        cout << "La cantidad no puede ser menor a 1.";
        return;
    }
    cout << "Precio unitario: ";
    cin >> _precioUnitario;
     if (_precioUnitario < 0){
        cout << "El precio no puede ser menor a 0.";
        return;
    }
    _importe = _cantidad * _precioUnitario;

    cout << "Forma de pago: ";
    cin.ignore();
    cin.getline(_formaPago, 20);

    _idVenta = arch.contarRegistros() + 1;

    _eliminado = false;
}
void Venta::mostrar() {
    cout << "ID Venta: " << _idVenta
         << " | Cliente: " << _idCliente
         << " | Empleado: " << _idEmpleado
         << " | Fecha: " << _fechaVenta.getDia() << "/"
                         << _fechaVenta.getMes() << "/"
                         << _fechaVenta.getAnio()
         << " | Producto: " << _idProducto
         << " | Cantidad: " << _cantidad
         << " | Precio: " << _precioUnitario
         << " | Importe: " << _importe
         << " | Pago: " << _formaPago
         << (_eliminado ? " [ELIMINADA]" : "") << endl;
}
int Venta::getIdVenta() { return _idVenta; }
void Venta::setIdVenta(int v) { _idVenta = v; }

int Venta::getIdCliente() { return _idCliente; }
void Venta::setIdCliente(int v) { _idCliente = v; }

int Venta::getIdEmpleado() { return _idEmpleado; }
void Venta::setIdEmpleado(int v) { _idEmpleado = v; }

Fecha Venta::getFechaVenta() { return _fechaVenta; }
void Venta::setFechaVenta(Fecha v) { _fechaVenta = v; }

int Venta::getIdProducto() { return _idProducto; }
void Venta::setIdProducto(int v) { _idProducto = v; }

int Venta::getCantidad() { return _cantidad; }
void Venta::setCantidad(int v) { _cantidad = v; }

float Venta::getPrecioUnitario() { return _precioUnitario; }
void Venta::setPrecioUnitario(float v) { _precioUnitario = v; }

float Venta::getImporte() { return _importe; }
void Venta::setImporte(float v) { _importe = v; }

const char* Venta::getFormaPago() { return _formaPago; }
void Venta::setFormaPago(const char* v) { std::strcpy(_formaPago, v); }

bool Venta::getEliminado() { return _eliminado; }
void Venta::setEliminado(bool v) { _eliminado = v; }
