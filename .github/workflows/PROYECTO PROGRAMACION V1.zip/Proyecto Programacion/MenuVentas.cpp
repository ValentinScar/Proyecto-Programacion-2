#include <iostream>
#include "MenuVentas.h"
#include "FuncionesMenuVentas.h"

using namespace std;

void MenuVentas() {
    int op;
    do {
        cout << "============= MENU VENTAS =============\n";
        cout << "1) Cargar venta\n";
        cout << "2) Listar todas las ventas\n";
        cout << "3) Eliminar venta\n";
        cout << "3) Recaudacion total por anio\n";
        cout << "4) Recaudacion por mes (anio/mes)\n";
        cout << "5) Buscar ventas por ID Cliente\n";
        cout << "6) Modificar forma de pago por ID\n";
        cout << "0) Volver\n";
        cout << "Opcion: ";
        cin >> op;
        cin.ignore();

        switch (op) {
            case 1: CargarVenta();        break;
            case 2: ListarVentas();       break;
            case 3: EliminarVenta();      break;
            case 4: RecaudacionPorAnio(); break;
            case 5: RecaudacionPorMes();  break;
            case 6: BuscarVentasPorCliente(); break;
            case 7: ModificarFormaPagoPorID(); break;
            case 0:break;
            default: cout << "Opcion invalida.\n"; break;
        }
        cout << "\n";
    } while (op != 0);
}
