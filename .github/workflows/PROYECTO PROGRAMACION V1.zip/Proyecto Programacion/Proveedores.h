#pragma once
#include <cstring>

class Proveedores {
private:
    int _idProveedor;
    char _nombre[50];
    char _telefono[20];
    char _email[50];
    char _direccion[50];
    bool _eliminado;

public:
    Proveedores() {
        _idProveedor = 0;
        std::strcpy(_nombre, "");
        std::strcpy(_telefono, "");
        std::strcpy(_email, "");
        std::strcpy(_direccion, "");
        _eliminado = false;
    }

    Proveedores(int idProveedor, const char* nombre, const char* telefono,
                const char* email, const char* direccion, bool eliminado) {
        _idProveedor = idProveedor;
        std::strcpy(_nombre, nombre);
        std::strcpy(_telefono, telefono);
        std::strcpy(_email, email);
        std::strcpy(_direccion, direccion);
        _eliminado = eliminado;
    }

    int getIdProveedor() { return _idProveedor; }
    void setIdProveedor(int v) { _idProveedor = v; }

    const char* getNombre() { return _nombre; }
    void setNombre(const char* v) { std::strcpy(_nombre, v); }

    const char* getTelefono() { return _telefono; }
    void setTelefono(const char* v) { std::strcpy(_telefono, v); }

    const char* getEmail() { return _email; }
    void setEmail(const char* v) { std::strcpy(_email, v); }

    const char* getDireccion() { return _direccion; }
    void setDireccion(const char* v) { std::strcpy(_direccion, v); }

    bool getEliminado() { return _eliminado; }
    void setEliminado(bool v) { _eliminado = v; }
}
;
