#pragma once

class DetalleVentas {
private:
    int _idDetalle;
    int _idVenta;
    int _idProducto;
    int _cantidad;
    float _precioUnitario;

public:
    DetalleVentas() {
        _idDetalle = 0;
        _idVenta = 0;
        _idProducto = 0;
        _cantidad = 0;
        _precioUnitario = 0;
    }
    DetalleVentas(int idDetalle, int idVenta, int idProducto, int cantidad, float precioUnitario) {
        _idDetalle = idDetalle;
        _idVenta = idVenta;
        _idProducto = idProducto;
        _cantidad = cantidad;
        _precioUnitario = precioUnitario;
    }

    int getIdDetalle() { return _idDetalle; }
    void setIdDetalle(int v) { _idDetalle = v; }

    int getIdVenta() { return _idVenta; }
    void setIdVenta(int v) { _idVenta = v; }

    int getIdProducto() { return _idProducto; }
    void setIdProducto(int v) { _idProducto = v; }

    int getCantidad() { return _cantidad; }
    void setCantidad(int v) { _cantidad = v; }

    float getPrecioUnitario() { return _precioUnitario; }
    void setPrecioUnitario(float v) { _precioUnitario = v; }
}
;
