#pragma once
void CargarVenta();
void ListarVentas();
void RecaudacionPorAnio();
void RecaudacionPorMes();
void BuscarVentasPorCliente();
void ModificarFormaPagoPorID();
