#include <iostream>
#include "Menu.h"
#include "rlutil.h"
#include "FuncionesGenerales.h"
#include "cliente.h"
#include "Venta.h"
#include "Producto.h"
#include "ClienteArchivo.h"
#include "ProductoArchivo.h"
#include "VentaArchivo.h"
#include "ProveedorArchivo.h"


using namespace std;


int flechaSeleccion(int y, int cantidadOpciones, bool &seleccionar) {
    int tecla = rlutil::getkey();

    switch (tecla) {
        case rlutil::KEY_UP:
            y--;
            if (y < 0) y = cantidadOpciones - 1;
            break;
        case rlutil::KEY_DOWN:
            y++;
            if (y >= cantidadOpciones) y = 0;
            break;
        case rlutil::KEY_ENTER:
            seleccionar = true;
            break;
        default:
            break;
    }
    return y;
}

int mostrarMenuPrincipal() {
    int y = 0;
    const int cantidadOpciones = 5;
    bool seleccionar = false;
    int yAnterior = -1;

    rlutil::cls();
    rlutil::locate(50, 10); cout << "--- MENU PRINCIPAL ---";
    rlutil::locate(55, 11); cout << "MENU CLIENTE";
    rlutil::locate(55, 12); cout << "MENU PRODUCTOS";
    rlutil::locate(55, 13); cout << "MENU VENTAS";
    rlutil::locate(55, 14); cout << "MENU PROVEEDORES";
    rlutil::locate(55, 15); cout << "SALIR";

    while (!seleccionar) {
        if (y != yAnterior) {

            if (yAnterior != -1) {
                rlutil::locate(53, 11 + yAnterior);
                cout << " ";
            }

            rlutil::locate(53, 11 + y);
            cout << (char)175;
            yAnterior = y;
        }
        y = flechaSeleccion(y, cantidadOpciones, seleccionar);
    }

    return y;
}

int mostrarMenuCliente() {
    int y = 0;
    const int cantidadOpciones = 6;
    bool seleccionar = false;
    int yAnterior = -1;

    rlutil::cls();
    rlutil::locate(50, 10); cout << "--- MENU CLIENTE ---";
    rlutil::locate(55, 11); cout << " AGREGAR CLIENTE";
    rlutil::locate(55, 12); cout << " BORRAR CLIENTE";
    rlutil::locate(55, 13); cout << " REACTIVAR CLIENTE";
    rlutil::locate(55, 14); cout << " VER CLIENTES";
    rlutil::locate(55, 15); cout << " BUSCAR CLIENTE";
    rlutil::locate(55, 16); cout << " VOLVER AL MENU PRINCIPAL";

    while (!seleccionar) {
        if (y != yAnterior) {

            if (yAnterior != -1) {
                rlutil::locate(53, 11 + yAnterior);
                cout << " ";
            }

            rlutil::locate(53, 11 + y);
            cout << (char)175;
            yAnterior = y;
        }
        y = flechaSeleccion(y, cantidadOpciones, seleccionar);
    }

    return y;
}

int mostrarMenuProductos() {
    int y = 0;
    const int cantidadOpciones = 4;
    bool seleccionar = false;
    int yAnterior = -1;

    rlutil::cls();
    rlutil::locate(50, 10); cout << "--- MENU PRODUCTOS ---";
    rlutil::locate(55, 11); cout << " AGREGAR PRODUCTO";
    rlutil::locate(55, 12); cout << " BORRAR PRODUCTO";
    rlutil::locate(55, 13); cout << " VER PRODUCTOS";
    rlutil::locate(55, 14); cout << " VOLVER AL MENU PRINCIPAL";

    while (!seleccionar) {
        if (y != yAnterior) {

            if (yAnterior != -1) {
                rlutil::locate(53, 11 + yAnterior);
                cout << " ";
            }

            rlutil::locate(53, 11 + y);
            cout << (char)175;
            yAnterior = y;
        }
        y = flechaSeleccion(y, cantidadOpciones, seleccionar);
    }

    return y;
}

int mostrarMenuVentas() {
    int y = 0;
    const int cantidadOpciones = 8;
    bool seleccionar = false;
    int yAnterior = -1;

    rlutil::cls();
    rlutil::locate(50, 10); cout << "--- MENU VENTAS ---";
    rlutil::locate(55, 11); cout << " NUEVA VENTA";
    rlutil::locate(55, 12); cout << " BORRAR VENTA";
    rlutil::locate(55, 13); cout << " LISTAR VENTAS";
    rlutil::locate(55, 14); cout << " REACTIVAR VENTA";
    rlutil::locate(55, 15); cout << " MAYOR IMPORTE POR ANIO";
    rlutil::locate(55, 16); cout << " RECAUDACION ANUAL";
    rlutil::locate(55, 17); cout << " RECAUDACION POR CLIENTE";
    rlutil::locate(55, 18); cout << " VOLVER AL MENU PRINCIPAL";

    while (!seleccionar) {
        if (y != yAnterior) {
            if (yAnterior != -1) {
                rlutil::locate(53, 11 + yAnterior);
                cout << " ";
            }
            rlutil::locate(53, 11 + y);
            cout << (char)175;
            yAnterior = y;
        }
        y = flechaSeleccion(y, cantidadOpciones, seleccionar);
    }

    return y;
}

int mostrarMenuProveedores() {
    int y = 0;
    const int cantidadOpciones = 6;
    bool seleccionar = false;
    int yAnterior = -1;

    rlutil::cls();
    rlutil::locate(50, 10); cout << "--- MENU PROVEEDORES ---";
    rlutil::locate(55, 11); cout << " ALTA PROVEEDOR";
    rlutil::locate(55, 12); cout << " LISTAR PROVEEDORES";
    rlutil::locate(55, 13); cout << " BAJA LOGICA";
    rlutil::locate(55, 14); cout << " REACTIVAR PROVEEDOR";
    rlutil::locate(55, 15); cout << " BUSCAR POR NOMBRE";
    rlutil::locate(55, 16); cout << " VOLVER AL MENU PRINCIPAL";

    while (!seleccionar) {
        if (y != yAnterior) {

            if (yAnterior != -1) {
                rlutil::locate(53, 11 + yAnterior);
                cout << " ";
            }

            rlutil::locate(53, 11 + y);
            cout << (char)175;
            yAnterior = y;
        }
        y = flechaSeleccion(y, cantidadOpciones, seleccionar);
    }

    return y;
}

long long ValidarDocumentoSegunTipo(int tipo) {
   rlutil::showcursor();
    Cliente c;
    int documento;
    long long documentoLargo;

    switch(tipo) {
        case 1:
            while(true) {
                documento = PedirEnteroValido("DNI: ");
                if(c.setDni(documento)) break;
                std::cout << "DNI invalido\n";
            }
            return documento;
            break;
        case 2:
            while(true) {
                documentoLargo = PedirEnteroValidoLargo("CUIT: ");
                if(c.setCuit(documentoLargo)) break;
                std::cout << "CUIT invalido\n";
            }
            return documentoLargo;
            break;
        default:
            std::cout << "Tipo invalido.\n";
            system("pause");
            return -1;
    }

    return documento;
}

int menuLogicoCliente() {
    rlutil::showcursor();
    int opcion;
    ClienteArchivo cA;
    Cliente c;
    do {
        opcion = mostrarMenuCliente();

        switch (opcion) {
            case 0: {
                system("cls");
                cout << "Agregar cliente...\n";
                cout << "--------------------------\n";

                int tipo = PedirEnteroValido("Tipo cliente: 1. Particular / 2. Empresa: ");
                long long documento = ValidarDocumentoSegunTipo(tipo);
                if(documento > 0) {
                    cA.altaCliente(documento, tipo);
                }
                break;
            }
            case 1: {
                system("cls");
                cout << "Borrar cliente...\n";
                cout << "--------------------------\n";
                cA.bajaLogica();
                system("pause");
                break;
            }
            case 2: {
                system("cls");
                cout << "Reactivar cliente...\n";
                cout << "--------------------------\n";
                cA.listarDocumentosDadosDeBaja();
                int tipo = PedirEnteroValido("Tipo cliente: 1. Particular / 2. Empresa: ");
                long long documento = ValidarDocumentoSegunTipo(tipo);
                if(documento > 0) {
                    int exito = cA.reactivarCliente(documento);
                    switch(exito){
                        case 0:
                            cout << "Ya esta activo"<<endl;
                            break;
                        case 1:
                            cout << "Reactivado"<<endl;
                            break;
                        case -1:
                            cout << "Error al guardar"<<endl;
                            break;
                        case -2:
                            cout << "Cliente no encontrado"<<endl;
                            break;
                    }

                    system("pause");
                }
                break;
            }
            case 3: {
                system("cls");
                cout << "CLIENTES\n";
                cout << "---------------------------------\n";
                cA.listarRegistros();
                system("pause");
                break;
            }
            case 4: {
                system("cls");
                cout << "BUSCAR CLIENTE..." << endl;

                int opcion = PedirEnteroValido("1. POR DOCUMENTO / 2. POR NOMBRE / 3. POR APELLIDO: ");

                switch(opcion) {
                    case 1: {
                        cout << "BUSCANDO POR DOCUMENTO..." << endl;
                        int tipo = PedirEnteroValido("TIPO DE CLIENTE: 1. Particular / 2. Empresa: ");
                        long long documento = ValidarDocumentoSegunTipo(tipo);
                        if (documento > 0) {
                            int pos = cA.BuscarPorDocumento(documento);
                            if (pos >= 0){
                                Cliente encontrado = cA.leerRegistro(pos);
                                encontrado.mostrar();
                                system("pause");
                            } else { cout << "Cliente no encontrado." << endl; }
                        }
                        break;
                    }
                    case 2: {
                        char nombre[30];
                        cout << "BUSCANDO POR NOMBRE..." << endl;
                        cout << "Nombre: ";
                        cin.getline(nombre, 30);

                        if (strlen(nombre) > 0) {
                            cA.BuscarPorNombre(nombre);
                        } else {
                            cout << "Entrada vac�a. Intente nuevamente." << endl;
                        }

                        system("pause");
                        break;
                    }

                    case 3: {
                        char apellido[30];
                        cout << "BUSCANDO POR APELLIDO..." << endl;
                        cout << "Apellido: ";
                        cin.getline(apellido, 30);

                        if (strlen(apellido) > 0) {
                            cA.BuscarPorApellido(apellido);
                        } else {
                            cout << "Entrada vac�a. Intente nuevamente." << endl;
                        }

                        system("pause");
                        break;
                    }

                    default:
                        cout << "Opci�n inv�lida." << endl;
                        break;
                }

            }
            case 5:
                cout << "Volviendo al menu principal...\n";
                break;
            default:
                cout << "Opcion invalida\n";
                system("pause");
        }
    } while (opcion != 5);

    return 0;
}

int menuLogicoProductos(){
    rlutil::showcursor();
    int opcion;
    ProductoArchivo pA;
    Producto p;

    do {
        opcion = mostrarMenuProductos();

        switch (opcion) {
            case 0: {
                system("cls");
                cout << "Agregar Producto...\n";
                cout << "--------------------------\n";
                pA.altaProducto();
                break;
            }
            case 1: {
                system("cls");
                cout << "Borrar producto...\n";
                pA.bajaLogica();
                system("pause");
                break;
            }
            case 2: {
                system("cls");
                cout << "PRODUCTOS\n";
                cout << "---------------------------------\n";
                pA.listarRegistros();
                system("pause");
                break;
            }
            case 3:  // VOLVER
                cout << "Volviendo al menu principal...\n";
                break;
            default:
                cout << "Opcion invalida\n";
                system("pause");
        }
    } while (opcion != 3);

    return 0;
}

int menuLogicoVentas() {
    int opcion;
    VentaArchivo pV;

    do {
        opcion = mostrarMenuVentas();

        switch (opcion) {
            case 0: {
                system("cls");
                cout << "Agregar Venta...\n";
                cout << "--------------------------\n";
                pV.altaVenta();
                system("pause");
                break;
            }
            case 1: {
                system("cls");
                cout << "Borrar venta...\n";
                int idVenta = PedirEnteroValido("INGRESE EL ID DE LA VENTA A BORRAR: ");
                bool ok = pV.bajaLogica(idVenta);
                cout << (ok ? "Baja realizada correctamente.\n" : "No se pudo dar de baja.\n");
                system("pause");
                break;
            }
            case 2: {
                system("cls");
                cout << "VENTAS REGISTRADAS\n";
                cout << "---------------------------------\n";
                pV.listarRegistros();
                system("pause");
                break;
            }
            case 3: {
                system("cls");
                cout << "Reactivar venta...\n";
                int id = PedirEnteroValido("INGRESE EL ID DE LA VENTA A REACTIVAR: ");
                int r = pV.reactivarVenta(id);
                switch (r) {
                    case 1:  cout << "Venta reactivada correctamente.\n"; break;
                    case 0:  cout << "La venta ya estaba activa.\n"; break;
                    case -1: cout << "Venta no encontrada.\n"; break;
                    case -2: cout << "Error al guardar la modificaci�n.\n"; break;
                }
                system("pause");
                break;
            }
            case 4: {
                system("cls");
                cout << "Buscar venta con mayor importe por anio\n";
                cout << "--------------------------------------\n";
                VentaArchivo Varch;
                Varch.BuscarMayorImportePorAnio();
                system("pause");
                break;
            }
            case 5:{
                system("cls");
                cout << "Buscar recaudacion anual\n";
                cout << "--------------------------------------\n";
                VentaArchivo Varch;
                int anio = PedirEnteroValido("Anio: ");
                if (anio > 2000 && anio < 2999) {
                    float total = Varch.recaudacionAnual(anio);
                    if (total >= 0) {
                        cout << "Recaudacion del anio " << anio << ": $" << total << endl;
                    } else {
                        cout << "Error al abrir el archivo de ventas.\n";
                    }
                } else {
                    cout << "Anio invalido.\n";
                }
                system("pause");
                break;
            }
            case 6: {
                system("cls");
                cout << "BUSCAR RECAUDACION POR CLIENTE\n";
                cout << "--------------------------------------\n";
                VentaArchivo Varch;
                int tipo = PedirEnteroValido("Tipo cliente: 1. Particular / 2. Empresa: ");
                long long documento = ValidarDocumentoSegunTipo(tipo);
                if(documento>0){
                    float total = Varch.recaudacionPorCliente(documento);
                    if (total >= 0) {
                        cout << "Recaudacion total del cliente con ID " << documento << ": $" << total << endl;
                    } else {
                        cout << "Error al abrir el archivo de ventas.\n";
                    }
                } else {
                    cout << "ID de cliente invalido.\n";
                }
                system("pause");
                break;
            }
            case 7:
                cout << "Volviendo al menu principal...\n";
                break;
            default:
                cout << "Opcion invalida\n";
                system("pause");
        }
    } while (opcion != 7);

    return 0;
}

int menuLogicoProveedores() {
    rlutil::showcursor();
    ProveedorArchivo pArch;
    int opcion;

    do {
        opcion = mostrarMenuProveedores();
        rlutil::cls();

        switch (opcion) {
        case 0: {
            std::cout << "--- ALTA PROVEEDOR ---\n";
            int res = pArch.altaProveedor();
            if (res == 1)       std::cout << "Proveedor cargado correctamente.\n";
            else if (res == 0)  std::cout << "El proveedor ya existe y esta activo.\n";
            else if (res == -2) std::cout << "El proveedor existia pero estaba dado de baja.\n";
            else                std::cout << "Error al guardar proveedor.\n";
            system("pause");
            break;
        }
        case 1: {
            std::cout << "--- LISTADO DE PROVEEDORES ACTIVOS ---\n";
            if (!pArch.listarRegistros()) {
                std::cout << "No se pudo abrir el archivo o no hay proveedores.\n";
            }
            system("pause");
            break;
        }
        case 2: {
            std::cout << "--- BAJA LOGICA DE PROVEEDOR ---\n";
            pArch.bajaLogica();
            system("pause");
            break;
        }
        case 3: {
            std::cout << "--- REACTIVAR PROVEEDOR ---\n";
            int id;
            std::cout << "INGRESE ID DE PROVEEDOR A REACTIVAR: ";
            std::cin >> id;
            std::cin.ignore();

            int res = pArch.reactivarProveedor(id);
            if (res == 1)       std::cout << "Proveedor reactivado correctamente.\n";
            else if (res == 0)  std::cout << "El proveedor ya estaba activo.\n";
            else if (res == -1) std::cout << "Proveedor no encontrado.\n";
            else                std::cout << "No se pudo reactivar el proveedor.\n";

            system("pause");
            break;
        }
        case 4: {
            std::cout << "--- BUSCAR PROVEEDOR POR NOMBRE ---\n";
            char nombre[50];
            std::cout << "NOMBRE: ";

            std::cin.getline(nombre, 50);

            int pos = pArch.buscarPorNombre(nombre);
            if (pos >= 0) {
                Proveedor prov = pArch.leerRegistro(pos);
                prov.mostrar();
            } else if (pos == -1) {
                std::cout << "No se encontro un proveedor activo con ese nombre.\n";
            } else {
                std::cout << "Error al abrir archivo de proveedores.\n";
            }

            system("pause");
            break;
        }
        case 5:
            break;
        }
    } while (opcion != 5);

    return 0;
}

